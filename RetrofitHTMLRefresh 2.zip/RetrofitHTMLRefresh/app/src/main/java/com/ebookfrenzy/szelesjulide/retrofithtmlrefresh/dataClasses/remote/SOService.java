package com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.remote;

import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.SOAnswersResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by szeles.julide on 2017/06/13.
 */

public interface SOService {

    @GET("answers?order=desc&sort=activity&site=stackoverflow")
    Call<SOAnswersResponse> getAnswers();

}
