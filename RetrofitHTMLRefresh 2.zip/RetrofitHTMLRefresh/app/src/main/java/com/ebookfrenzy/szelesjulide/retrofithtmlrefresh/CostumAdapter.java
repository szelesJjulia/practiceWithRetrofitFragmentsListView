package com.ebookfrenzy.szelesjulide.retrofithtmlrefresh;

import android.content.ClipData;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.Item;

import java.util.ArrayList;

/**
 * Created by szeles.julide on 2017/06/13.
 */

public class CostumAdapter extends ArrayAdapter<Item> {
    private ArrayList<Item>dataSet;
    Context myContext;

    private static class ViewHolder{
        TextView textTitle;
        TextView smt1;
        TextView smt2;

    }

    public CostumAdapter(ArrayList<Item> data,Context context){
        super(context,R.layout.raw_item,data);
        this.dataSet = data;
        this.myContext = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Item item = getItem(position);
        ViewHolder viewHolder;

        final View result;
        if (convertView == null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.raw_item,parent,false);
            viewHolder.textTitle = (TextView)convertView.findViewById(R.id.textViewTitle);
            viewHolder.smt1 = (TextView)convertView.findViewById(R.id.textViewValami);
            viewHolder.smt2 = (TextView)convertView.findViewById(R.id.textViewValami2);

            result = convertView;
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }


        viewHolder.textTitle.setText(item.getOwner().getDisplayName());
        viewHolder.smt1.setText(item.getOwner().getReputation().toString());
        viewHolder.smt2.setText(item.getOwner().getUserId().toString());

        return convertView;
    }
}
